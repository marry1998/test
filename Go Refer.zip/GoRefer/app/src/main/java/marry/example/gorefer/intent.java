package marry.example.gorefer;

public class intent {
    public intent(MainActivity mainActivity, Class<Activity_CreatePost> activity_createPostClass) {


    }
}
